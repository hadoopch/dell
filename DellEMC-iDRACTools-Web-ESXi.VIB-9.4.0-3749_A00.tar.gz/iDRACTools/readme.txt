The package that you downloaded contains the following tools:
� RACADM

==========================================================================================
Release summary
==========================================================================================
The Integrated Dell Remote Access Controller (iDRAC) is designed to make server administrators
more productive and improve the overall availability of Dell servers.

iDRAC alerts administrators to server issues, helps them perform remote server management, and
reduces the need for physical access to the server. Additionally, iDRAC enables administrators
to deploy, monitor, manage, configure, update, and troubleshoot Dell EMC servers from any location
without using any agents. It accomplishes this regardless of the operating system or hypervisor
presence or state.

iDRAC provides out-of-band mechanisms for configuring the server, applying firmware updates,
saving or restoring a system backup, or deploying an operating system, by using the iDRAC GUI, the
iDRAC RESTful API or the RACADM command line interface.

This release of the RACADM command line interface includes updated packaging supporting
the installation of both local and remote RACADM and fixes to issues documented below.

------------------------------------------------------------------------------------------
Version
------------------------------------------------------------------------------------------
Dell EMC iDRAC Tool for ESXi  v9.4.0

------------------------------------------------------------------------------------------
Release date
------------------------------------------------------------------------------------------
December 2019

==========================================================================================
New and enhanced features
==========================================================================================
RACADM:
� Support added for https bootcert management feature. Tracking number: RACADM-856
� Support added for Force change password feature for the supporting iDRAC firmware. 
  Tracking number: RACADM-896
� Support added for serial data capture feature. Tracking number: RACADM-965
� Support added for returning proper exit codes for each racadm call. Tracking number: IDLC-1605

==========================================================================================
Fixes
==========================================================================================
RACADM:
   . Fixed issue related to fwupdate for handling unsupported firmware update files. 
     Tracking number: 137459
   . Fixed memory related issues. Tracking number: 144661
   . Fixed issue related to SCP export from local racadm not generating any file. 
     Tracking number: 147950
   . Fixed issue related to TSR export failing from local racadm. Tracking number: 148018
   . Fixed issue related to FSD. Tracking number: 150730

==========================================================================================
Known issues
==========================================================================================
RACADM:
 N/A

==========================================================================================
Installation
==========================================================================================
RACADM:
1. Copy the DellEMC-iDRACTools-Web-ESXi.VIB-9.4.0-3227.tar.gz and untar the file.

2. Run tar -zxvf on the tar.gz to unzip the contents into the current directory.

3. Inside the folder where it is extracted, navigate to iDRACTools/racadm folder and 
   based on the ESXi version go to the ESXi<version> folder.

4. For exmample: On ESXi6.5 machine, Copy the Racadm-Dell-EMC-Web-9.4.0-3227.VIB-ESX65i.zip in the ESXi machine.

5. To install the Racadm package, run the esxcli software vib command as illustrated below.
   [root@localhost:/var/log/vmware] esxcli software vib install -d  Racadm-Dell-EMC-Web-9.4.0-3227.VIB-ESX65i.zip
	Installation Result
	   Message: Operation finished successfully.
	   Reboot Required: false
	   VIBs Installed: DEL_bootbank_racadm_9.4.0.ESXi650-3227
	   VIBs Removed:
	   VIBs Skipped:

6. This will install the Racadm package. It can be cross verified using the below command.
    [root@localhost:/var/log/vmware] esxcli software vib list | grep racadm
	racadm                         9.4.0.ESXi650-3227                   DEL    PartnerSupported  2018-10-25

7. Now user can run racadm commands.
   [root@localhost:~] racadm getractime
	Fri Nov 24 11:04:28 2017

8. To uninstall the Racadm package, run the below command.
   [root@localhost:/var/log/vmware] esxcli software vib remove --vibname=racadm
	Removal Result
	   Message: Operation finished successfully.
	   Reboot Required: false
	   VIBs Installed:
	   VIBs Removed: DEL_bootbank_racadm_9.4.0.ESXi650-3227
	   VIBs Skipped:

Note:
1.  To run the below set of local racadm commands, usbarbitrar needs to be disabled in the host.
	The command list are as follows:
	[racadm update, fwupdate, lclog, get/set (file operations), getconfig/config (file operations),  techsupreport, supportassist, hwinventory,swinventory, bioscert, inlettemphistory and gethostnetworkinterfaces.] 
	This is because usb partition will be attached with host for these commands. 
	
	To disable usbarbitrar, run the below command:
	[root@localhost:~]/etc/init.d/usbarbitrator stop

	When usbarbitrar is enabled and when the above racadm commands are run, user is notified with the below error message.
	ERROR: usbarbitrar is enabled. Disable usbarbitrar by running "/etc/init.d/usbarbitrator stop" and retry the command.
	
2.  To run remote racadm commands, firewall need to be disabled.
    
	To disable firewall completely, run the below command:
	[root@localhost:~]esxcli network firewall unload
 
    Alternatively, User also can set the specific rules for the IP and port to disable the firewall.


==========================================================================================
Resources and support
==========================================================================================
------------------------------------------------------------------------------------------
Accessing documents using direct links
------------------------------------------------------------------------------------------
You can directly access the documents using the following links:
� dell.com/idracmanuals			 �	iDRAC and Lifecycle Controller
� dell.com/openmanagemanuals	 �	Enterprise System Management
� dell.com/serviceabilitytools	 �	Serviceability Tools
� dell.com/OMConnectionsClient	 �	Client System Management
� dell.com/OMConnectionsClient	 �	OpenManage Connections Client systems management 
� dell.com/OMConnectionsEnterpriseSystemsManagement � OpenManage Connections Enterprise
                                                      Systems Management

------------------------------------------------------------------------------------------
Accessing documents using product selector
------------------------------------------------------------------------------------------
You can also access documents by selecting your product.
1. Go to dell.com/manuals.
2. In the All products section, click Software --> Enterprise Systems Management.
3. Click the desired product and then click the desired version, if applicable.
4. Click Manuals & documents. 

==========================================================================================
Contacting Dell EMC
==========================================================================================
Dell EMC provides several online and telephone-based support and service options.
Availability varies by country and product, and some services may not be available in
your area. To contact Dell EMC for sales, technical support, or customer service issues,
go to www.dell.com/contactdell.

If you do not have an active Internet connection, you can find contact information on
your purchase invoice, packing slip, bill, or the product catalog.

==========================================================================================
Information in this document is subject to change without notice.
� 2019 Dell Inc. or its subsidiaries. All rights reserved.
Dell, EMC, and other trademarks are trademarks of Dell Inc. or its subsidiaries.
Other trademarks may be trademarks of their respective owners.

Rev: A00