#!/bin/sh
#function to uninstall IR rpm's
function UninstallPkgs()
{
	rpm -q srvadmin-omilcore >/dev/null
	if [ $? -eq 0 ]; then
		echo "OMSA is already installed in the system. Uninstall OMSA and try again to uninstall racadm."
	else
		rpm -e srvadmin-argtable2 srvadmin-hapi srvadmin-idracadm7
	fi
}
UninstallPkgs
