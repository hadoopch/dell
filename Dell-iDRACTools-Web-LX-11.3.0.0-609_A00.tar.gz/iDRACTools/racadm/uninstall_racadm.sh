#!/bin/bash
#function to uninstall IR rpm's
function RemovePath()
{
	echo $PATH | tr ":" "\n" | grep "/opt/dell/srvadmin/sbin" >/dev/null
	if [ $? -eq 0 ]; then
		PATH=`echo $PATH | sed -e 's/:\/opt\/dell\/srvadmin\/sbin\/$//'`
        if [[ "$ID" == "rhel" || "$ID" == "centos" ]]; then
            sed -i '/opt\/dell\/srvadmin\/sbin/d' /etc/bashrc
		else
			sed -i '/opt\/dell\/srvadmin\/sbin/d' /etc/bash.bashrc
        fi
	fi
	rm -f /etc/profile.d/dractools.sh
}
function UninstallUbuntuPkgs()
{
    dpkg -s srvadmin-omilcore >/dev/null
	if [ $? -eq 0 ]; then
		dpkg --purge srvadmin-idracadm7 srvadmin-idracadm8
	else
		dpkg --purge srvadmin-hapi srvadmin-idracadm7 srvadmin-idracadm8
	fi
}
function UninstallPkgs()
{
	rpm -q srvadmin-omilcore >/dev/null
	if [ $? -eq 0 ]; then
		rpm -e srvadmin-argtable2  srvadmin-idracadm7
	else
		rpm -e srvadmin-argtable2 srvadmin-hapi srvadmin-idracadm7
	fi
}
OS="None"
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
fi
if [ "$OS" == "Ubuntu" ]
then
    UninstallUbuntuPkgs
    RemovePath	
else
    UninstallPkgs
    RemovePath	
fi
